from kmk.kmk_keyboard import KMKKeyboard
from kmk.scanners import DiodeOrientation
from kmk.keys import KC
from kmk.modules.layers import Layers
from kmk.modules.encoder import EncoderHandler
from kmk.modules.oled import OLED, OledDisplayMode, OledReactionType
from kmk.modules.split import Split, SplitType
import board
import digitalio
import supervisor

keyboard = KMKKeyboard()

# Matrix pins
keyboard.col_pins = (board.GP3, board.GP4, board.GP5)
keyboard.row_pins = (board.GP0, board.GP1, board.GP2)
keyboard.diode_orientation = DiodeOrientation.COL2ROW

# Modules
layers = Layers()
encoders = EncoderHandler()
oled = OLED()
keyboard.modules = [layers, encoders, oled]

# LED backlight setup on GP1 (shared with row pin, toggled via key)
led = digitalio.DigitalInOut(board.GP1)
led.direction = digitalio.Direction.OUTPUT
led.value = True  # On by default

# Encoder setup
encoder_modes = ['VOL', 'ZOOM', 'BRI', 'SCRL']
current_encoder_mode = 0

# Display current mode on OLED
def get_oled_lines():
    return [
        f'Layer: {keyboard.active_layers[-1]}',
        f'Encoder: {encoder_modes[current_encoder_mode]}'
    ]

oled.display_mode = OledDisplayMode.TXT
oled.reaction_type = OledReactionType.KEYPRESS
oled.lines = get_oled_lines
oled.i2c = board.I2C()  # Uses default GP6=SDA, GP7=SCL

# Key aliases
_______ = KC.TRNS

# Define your layers
keyboard.keymap = [
    # Layer 0: Shortcuts (Media + Edit)
    [
        KC.MPRV, KC.MPLY, KC.MNXT,   # Top row: media
        KC.UNDO, KC.REDO, KC.SAVE,   # Middle: undo/redo/save
        KC.COPY, KC.PASTE, KC.CUT,   # Bottom: copy/paste/cut
    ],
    # Layer 1: Numpad (1 bottom left, 9 top right)
    [
        KC.N7, KC.N8, KC.N9,
        KC.N4, KC.N5, KC.N6,
        KC.N1, KC.N2, KC.N3,
    ]
]

# Encoder rotation per mode
def update_encoder(mode):
    if mode == 'VOL':
        return ((KC.VOLD, KC.VOLU),)  # Volume
    elif mode == 'ZOOM':
        return ((KC.LCTRL(KC.MINUS), KC.LCTRL(KC.EQUAL)),)
    elif mode == 'BRI':
        return ((KC.BRIGHTNESS_DOWN, KC.BRIGHTNESS_UP),)
    elif mode == 'SCRL':
        return ((KC.LEFT, KC.RIGHT),)

# Set initial encoder action
encoders.encoder_map = update_encoder(encoder_modes[current_encoder_mode])

# Encoder: GP29 = A, GP0 = B, button (EC11) = GP2 + GP5 (row+col)
keyboard.encoder_pins = ((board.GP29, board.GP0, None),)

# Layer toggle combo: Press EC11 switch (mapped to GP2+GP5 = index 8) + another key (e.g. index 0) = toggle layer
keyboard.keymap[0][8] = KC.MO(1)  # Assign EC11 "button" combo to momentary Layer 1 (numpad)
keyboard.keymap[1][8] = KC.MO(0)  # Back to Layer 0

# Encoder button cycles encoder mode (you can assign it via matrix combo)
from kmk.handlers.sequences import simple_key_sequence
def toggle_encoder_mode():
    global current_encoder_mode
    current_encoder_mode = (current_encoder_mode + 1) % len(encoder_modes)
    encoders.encoder_map = update_encoder(encoder_modes[current_encoder_mode])
    print('Encoder mode:', encoder_modes[current_encoder_mode])

keyboard.after_scan_callback = toggle_encoder_mode  # You can condition this based on a combo

# Optional: Key combo to toggle LED (e.g. top-left + bottom-right)
from kmk.handlers.sequences import send_string
from kmk.modules.combos import Combos, Chord

combos = Combos()
keyboard.modules.append(combos)
combos.combos = [
    Chord((0, 8), KC.NO, on_press=lambda: led_toggle())
]

def led_toggle():
    led.value = not led.value

if __name__ == '__main__':
    keyboard.go()

