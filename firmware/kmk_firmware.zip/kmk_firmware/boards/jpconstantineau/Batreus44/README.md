# JPConstantineau's Batreus44: An Atreus44 clone with Low Profile Switches and Wireless Options!

![Batreus44](https://preview.redd.it/yu090ikxiou71.jpg?width=4032&format=pjpg&auto=webp&s=6da758f1ca439ecee912b35a709eacef9b019cd8)

44 Keys Low Profile Keyboard inspired from Keyboardio's Atreus with a socket for a NiceNano, BlueMicro840 or Pro Micro RP2040 and a place to solder in a Battery.

`kb_BlueMicro840.py` is designed to work with the BlueMicro840

Extensions enabled by default  
- [Layers](/docs/en/layers.md) Need more keys than switches? Use layers.
- [MediaKeys](/docs/en/media_keys.md) Control volume and other media functions
